<?php
	
	$server = 'localhost';
	$username = 'root';
	$password = 'root';
	$database = 'fakultet';

	$dbc = mysqli_connect($server, $username, $password);

	if( $dbc ) {
		echo 'Spajanje uspješno <br>';

		if( mysqli_select_db( $dbc, $database ) ) {
			mysqli_query( $dbc, "SET NAMES 'utf8'" );
			echo 'Baza uspješno odabrana <br>';
		} else {
			echo 'Baza nije odabrana <br>';
		}

	} else {
		echo 'Neuspješno spajanje <br>';
	}

?>